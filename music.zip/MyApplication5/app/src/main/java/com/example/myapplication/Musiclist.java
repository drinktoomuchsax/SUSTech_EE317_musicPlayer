package com.example.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;

import androidx.annotation.Nullable;

public class Musiclist extends Activity{
    @Override

    protected void onCreate(@Nullable Bundle saveInstanceState) {

        ListView mLv1;

        super.onCreate(saveInstanceState);
        setContentView(R.layout.musiclist);
        mLv1 = (ListView)findViewById(R.id.lv_1);
        mLv1.setAdapter(new ListAdaptor(Musiclist.this));
    }
}
